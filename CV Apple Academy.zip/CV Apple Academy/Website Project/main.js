function openDashboard(){
    window.location.replace('dashboard.html')
}

var sl_ap = document.getElementById('sl_ap');

// sl_ap.style.opacity = 0;
// sl_ap.style.visibility = "hidden";

// function showAdminProfile(){
//     sl_ap.style.opacity = 1;
//     sl_ap.style.visibility = "visible";
//     sl_ap.style.transition = "all 0.8s"
// }

// function hideAdminProfile(){
//     sl_ap.style.opacity = 0;
//     sl_ap.style.visibility = "hidden";
//     sl_ap.style.transition = "all 0.8s"
// }
function validateusername(){
    var username = document.getElementById("user-name")

    if(username.value == ""){
        alert("No blank values")
    }
}