//menggunakan tipe data

//var= variable

//tipe data string
var namaSaya = "Fadli"

//int
var umurSaya = 22;

var teman = {
    namaDia: "anonim",
    umurDia: 21,
    jenisKelamin: "lelaki"
}


console.log(namaSaya + umurSaya);

// Operasi Aritmatika
/*var myBalance = 1000;
var totalHarga = 10000;
ini dipindahkan ke call function valuenya
*/
// var totalKembalian = myBalance - totalHarga; (dipindahkan ke dalam function karena ada parameter set)

//function plus pake parameter
function pengingatUserWallet(myBalance, totalHarga) {

    var totalKembalian = myBalance - totalHarga;

    if (myBalance < totalHarga) {
        //totalKembalian = "Uang anda tidak cukup untuk melakukan transaksi";
        alert("Uang tidak cukup");
    }
    else if (myBalance >= totalHarga) {
        var totalKembalian = myBalance - totalHarga;
    }
    else {
        var totalKembalian = myBalance - totalHarga;
    }

    document.getElementById("user-name").innerHTML = namaSaya + '.' + umurSaya + 'Total Balance : ' + totalKembalian;

}

//menjalankan function
pengingatUserWallet(10000, 1000);

//membuat object
var pengguna = {
    namaUser : "Fadli Alfiansyah",
    jumlahWisata : 3,
    totalBalance : 12000
}

console.log(pengguna.namaUser);

//array
var cars = ["BMW", "Merce", "Toyota", "Kijang"];
//cars[0] = "Mercedes"; (buat ganti isi array)
//cars.push("audi") untuk menambah variable dalam array
cars.pop();
console.log(cars);

//var teman untuk data array buat switch
var teman = ["Allie", "Wisnu", "Tama", "Madia", "Fira", "Kuse"]
//membuat variable baru untuk switch
var temanBaikSaya = teman[0];
//buat switch untuk validasi variable nama
switch (temanBaikSaya){
    case "Allie":
    alert('Welcome Allie');
    document.getElementById('user_logging').innerHTML = "Allie";
    break;

    case "Wisnu":
    alert('Selamat Datang Wisnu');
    document.getElementById('user_logging').innerHTML = "Wisnu";
    break;

    case "Tama":
    alert('Monggo pak Tama');
    document.getElementById('user_logging').innerHTML = "Tama";
    break;

    default:
    alert('maaf data anda tidak ada');
    document.getElementById('user_logging').innerHTML = "Tidak ada";
    break;
}

//for loop
var i;//i sebagai patokan
for(i=0; i < teman.length; i++){
    console.log(teman[i]);
    if(teman[i] == "Fira"){
        break;
    }
}

function bindingDatauser(){
    document.getElementById('nama_user').innerHTML = pengguna.namaUser;
    document.getElementById('jumlah_wisata').innerHTML = pengguna.jumlahWisata;
}

bindingDatauser();
/*document.getElementById("user-age") .innerHTML = teman.umurDia ; */
//console.log(totalKembalian);


//buat funtion on click ke page lain
function openTicket(){
    alert("halaman belum siap digunakan");
    window.location.replace('website.html')
}

function openDashboard(){
    window.location.replace('dashboard.html')
}