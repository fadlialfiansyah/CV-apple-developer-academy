function validateUsername(){
    var username = document.getElementById("uname")

    if(username.value == ""){
        alert("No blank values")
    }
}